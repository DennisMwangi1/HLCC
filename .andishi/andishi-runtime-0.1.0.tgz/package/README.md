# @andishi/runtime

Andishi in a React site: the Site API client, hooks for the store, bookings,
quotes and the CMS, and the editable copy components. A site built with its own
framework (Next.js, Vite, Remix, …) uses the provider and the hooks; Andishi's
hosted sites also use the router and the Vite plugin.

```sh
npm install @andishi/runtime
```

| Import | What it is |
| --- | --- |
| `@andishi/runtime/react` | `AndishiProvider`, `usePageContent`, and the hooks a client component uses. A client module (`"use client"`). |
| `@andishi/runtime/server` | Async reads for a server component or a build script: `getPageContent`, `getArticles`, `getArticle`, `getCategories`, `getCollection`, `getComments`. No React, no browser. |
| `@andishi/runtime` | Everything above except the provider, plus the synchronous data helpers (`field`, `imageField`, `fetchCollection`, `fetchContent`), `Text` and `Image` |
| `@andishi/runtime/app` | Hosted sites: `startSite()`, React Router (data mode), page loaders, `<head>` sync |
| `@andishi/runtime/vite` | Hosted sites: `andishiRoutes()`, which turns `src/pages` into routes and writes `routes.json` |
| `@andishi/runtime/virtual` | Types for `virtual:andishi/routes` |

## Use it from your own site

Wrap the app in the provider with the Site API's address and the site's
publishable key (`pk_live_…`, from the studio). The key identifies the site and
is not a secret.

```tsx
import { AndishiProvider } from '@andishi/runtime/react'

export function App() {
  return (
    <AndishiProvider config={{ apiUrl: 'https://api.example.com', siteKey: 'pk_live_…' }}>
      <Routes />
    </AndishiProvider>
  )
}
```

The site's origin must be one of the site's registered origins, or the Site API
refuses the browser's requests.

Requests are sent with `credentials: 'same-origin'`, so a shopper's sign-in
cookie only reaches the Site API when the site serves it from its own origin
(proxy a path such as `/api` to the Site API's `/` and set `apiUrl: '/api'`). Carts,
orders, bookings and quotes carry their tokens in headers and work across
origins.

### Page copy

`usePageContent` loads the copy the site owner edits in the studio, by page path.
`Text`, `Image` and `field()` then render it, and fall back to their own text
until it arrives or when a field is empty.

```tsx
import { Text, usePageContent } from '@andishi/runtime/react'

function About() {
  const page = usePageContent({ path: '/about', sections: ['/'] })
  return (
    <main>
      <Text section="hero" field="title" path="/about" as="h1" fallback="About us" />
      <p>{page.field('hero', 'intro', 'We bake bread every morning.')}</p>
    </main>
  )
}
```

`sections` names other pages whose copy this page also reads (a footer kept on
`/`). `collections`, `content` and `entry` load Custom Modules, posts by channel
and one post, for `fetchCollection`, `fetchContent` and `fetchContentBySlug`.

### Server rendering (Next.js app router)

Every module loads without a browser, so a client component renders on the
server. To send the copy in the first HTML, read it in a server component and
hand it to the provider:

```tsx
// app/layout.tsx (a server component)
import { getPageContent } from '@andishi/runtime/server'
import { AndishiProvider } from '@andishi/runtime/react'

const config = { apiUrl: process.env.ANDISHI_API_URL!, siteKey: process.env.NEXT_PUBLIC_ANDISHI_SITE_KEY! }

export default async function Layout({ children }: { children: React.ReactNode }) {
  const page = await getPageContent({ path: '/' }, { config })
  return (
    <html><body>
      <AndishiProvider config={config} initialData={page.data}>{children}</AndishiProvider>
    </body></html>
  )
}
```

Pass `config` to each server read: the provider's settings are one per process,
and a server read never relies on them.

### Store, bookings and quotes

| Hook | What it does |
| --- | --- |
| `useCatalogProducts`, `useProduct`, `useProductCategories` | The catalogue |
| `useCart`, `useCheckout`, `usePayment` | Cart, checkout and payment (see Payments below) |
| `useBooking(slug)`, `useManageBooking(id)` | A visitor's booking of one service, and managing it (see Bookings) |
| `useQuoteRequest()` | Sends a request for a quote: `submit({ contactName, email, phone, requirements, items, answers })` |
| `useQuote(id)` | Reads a quote and accepts or declines it |

`answers` is the site's own form fields, such as an event date or a guest count:
at most 30 keys (`a-z`, digits and `_`, starting with a letter), each answer at
most 500 characters. The quote's access token is kept by the runtime
(`andishi:quote` in `localStorage`, one record per quote, 30 days) and read from
an emailed link's `#token=`; page code never sees it. Accepting a quote that
becomes an order keeps the order's buyer token, so the order page can pay it.

### CMS

| Hook | Server read | Route |
| --- | --- | --- |
| `useArticles({ category, page, limit })` | `getArticles` | `GET /site/v1/articles` |
| `useArticle(slug)` | `getArticle` | `GET /site/v1/articles/by-slug/{slug}` |
| `useCategories()` | `getCategories` | `GET /site/v1/categories` |
| `useCollection(slug)` | `getCollection` | `GET /site/v1/collections/{slug}` |
| `useComments(articleId)` (with `post`) | `getComments`, `postComment` | `GET`/`POST /site/v1/comments` |

Each hook returns `loading`, `error` (the visitor's words) and `reload`.
`useArticle` adds `notFound`. Comments are moderated: a posted comment appears
once the site owner approves it.

The newsletter and contact forms are `useSubscribe` and `useContactForm`.

### Visual editing

`AndishiProvider` takes an `edit` option (`{ studioOrigin }`, default
`https://studio.andishi.site`) for in-place editing from the studio's **Content →
Edit content**. When the page is framed by that studio, the bridge says hello
with the site's publishable key and origin; the studio checks both, then sends a
short-lived edit token. The client adds it as `X-Andishi-Edit` on page reads, so
the page shows drafts while it is being edited. Outside the studio's frame the
bridge never starts. Your site must allow the studio in `frame-ancestors`
(see the visual-editing guide).

## Hosted sites

Andishi's own sites are single-page apps: the site app (`scaffolds/site`) is
built once with Vite, the platform assembles each site's build from it, and the
edge Worker serves the build. The rest of this README describes that path.

## How a page gets its data

1. The build reads each page and every local module it imports, plus the
   site layout (`src/root.tsx`), and lists what the page reads. The result
   goes to `routes.json`.
2. On the first request, the Worker matches the path against `routes.json`,
   calls `GET /site/v1/page` once, and embeds the result in `index.html`.
3. In the browser, the route loader reads the embedded data for the first
   page. On later navigations it makes one `GET /site/v1/page` request
   before the page renders.
4. Components read the loaded data synchronously. Data accumulates by key,
   so the outgoing page keeps rendering correctly while the next one loads.
5. The page route (`src/pages/[...path].tsx`, `/*` in `routes.json`) takes
   every path no other route takes. It asks for `path` and `layout=1` instead
   of the lists: the page's layout (`pageLayout(path)`) and the site's
   (`siteLayout()`). When the Site API has no page at the path, it renders the
   404 page.

Only CMS data is embedded or cached this way. Prices, stock, carts and
orders come from the commerce API live, from client components.

## Editable copy (`Text`, `Image`)

Visible copy and photos are written as components, so the studio can edit them
in place (VISUAL-EDITING.md):

```tsx
<Text section="hero" field="title" as="h1" fallback="Fresh bread every morning" />
<Image section="hero" field="photo" fallbackSrc="/photo.jpg" fallbackAlt="Bread" className="w-full" />
```

Outside edit mode they render what `field` and `imageField` render in JSX: the
same text, or the same `<img>`. Optional props: `path` (the page showing the
copy, default `/`), `className`, and for `Text`, `as` (one of the elements in
`TEXT_TAGS`; without it the text is rendered bare). Every prop must be a string
literal: the build gate refuses a computed prop, and the route analysis
(`src/vite/analyze.ts`) reads the section of each element from its literal `path`.

A field of one item of a list field takes `list` (the list's field key) and
`item` (the item's id), both or neither: `<Text section="menu" list="dishes"
item="k3f9a" field="title" fallback="Dish" />`. The value is the item's `field`.
The build gate checks generated code only; the site app's template sections
pass computed values.
`listItems(section, field, path)` returns a list's items, and never throws on
malformed data.

On a preview framed by the studio, the bridge (`src/edit/`) marks each element
with `data-andishi-edit` and makes the selected `Text` editable in place. The
bridge is a separate chunk. `src/edit/start.ts` decides whether it starts, from the
framing, the preview host, the studio origin in `window.__ANDISHI__` and the
studio's answer to the hello. `src/edit/protocol.ts` is the message schema both
sides check; `src/store.ts` gives the components a change signal, which a
`value` message from the studio uses.

## Page views (the beacon)

`startSite` installs the page-view beacon (`src/app/beacon.ts`). It records the
document's first page and each route change the router completes, and posts the
path (with only the UTM values of the query), the referrer on the first page and
the viewport width to `/_api/collect` on the site's own origin: `sendBeacon` with
a JSON blob, or `fetch` with `keepalive`. It stores nothing in the browser.

It is off on a preview host, on a prerendered page, under `navigator.webdriver`,
and on a page the Worker did not serve (no `window.__ANDISHI__`). The beacon is
internal: it is not exported from the package's public names, and
`kit/sitebuild/policy.json` does not list it, so generated code cannot import or
call it. ANALYTICS.md has the contract.

### Rule for generated code

Data helper arguments must be string literals, so step 1 can see them:

```tsx
field('hero', 'heading', 'Welcome', '/about')   // reads /about
fetchCollection('team')                         // reads the team module
fetchContent({ category: 'journal' })           // reads the journal channel
<Hero path="/about" />                          // locked components: path, moduleSlug, category props
```

A computed path argument is read as `/`; a computed collection slug is not
loaded at all. The AI server's validator rejects both.

## routes.json

Written next to `index.html` in every build.

```json
{
  "version": 1,
  "base": "/_build/0f8fad5b-d9cb-469f-a165-70867728950e/",
  "routes": [
    {
      "path": "/journal/:slug",
      "file": "src/pages/journal/[slug].tsx",
      "data": {
        "sections": ["/", "/journal"],
        "collections": [],
        "content": ["journal"],
        "entry": "slug"
      }
    }
  ],
  "notFound": { "sections": ["/"], "collections": [], "content": [] }
}
```

- `path`: React Router path. `src/pages/index.tsx` is `/`,
  `src/pages/blog/[slug].tsx` is `/blog/:slug`. Files and folders that
  start with `_` or `.` are not routes. `src/pages/[...path].tsx` is `/*`, the
  page route: it matches last, for any number of segments.
- `data.sections`: page paths whose section copy the route reads.
- `data.collections`: Custom Module slugs.
- `data.content`: publishing channels; `""` means every channel.
- `data.entry`: the route parameter holding a post slug.
- `data.page`: true for the page route, which reads no lists (see above).
- `notFound`: what the 404 page reads (the layout's data).
- `base`: the URL prefix of this build's files (see below).

## Build files

The site app is built with `ANDISHI_BUILD_ID` set, and the platform's
assembler replaces that prefix with each build's id (a lowercase UUID). Every file the build references is then served under
`/_build/{buildId}/`, for example
`/_build/0f8f…/assets/index-a1b2c3.js`. A page therefore always loads code
from the build that produced it, whether that build is live, a retained
build an open tab still uses, or a preview. Page paths that start with `_`
are never routes, so the prefix cannot collide with a site page. Builds
without the variable (local development) use `/`.

## Site API

The gateway serves these under `/site/v1`. In production the Worker
proxies `/_api/*` on the site's own origin to it and injects
`apiUrl: "/_api"`, so the shopper sign-in cookie is first-party. GET
requests carry the site's publishable key as `?key=`; POST requests carry
it as `publishable_key` in the JSON body. Requests are sent with
`credentials: 'same-origin'`: cookies go to the site's own `/_api` and
never to another origin. Errors return a JSON body with `code` or
`error.code`.

| Request | Response |
| --- | --- |
| `GET /site/v1/page?path&sections&collections&content&entry` | `{ meta, data }` |
| `GET /site/v1/collections/{slug}` | `{ entries: CollectionEntry[] }` |
| `GET /site/v1/content?category=` | `{ posts: WrittenContent[] }` |
| `GET /site/v1/photo-credits` | `{ credits: PhotoCredit[] }` |
| `POST /site/v1/contact` | `204` or `{}` |
| `POST /site/v1/subscribers` | `204` or `{}` |

`sections`, `collections` and `content` are comma-separated lists from
`routes.json`; `entry` is the value of the route's entry parameter.

`data` has this shape (every key optional):

```ts
{
  sections: { [path]: { [section]: { [field]: string | { src, alt } } } },
  collections: { [slug]: CollectionEntry[] },   // published and draft; the runtime keeps published
  content: { [channel]: WrittenContent[] },
  contentBySlug: { [slug]: WrittenContent | null },
}
```

`meta` fills `<head>`: `{ title, description, canonical, image, noindex, jsonld[] }`.

Visitor-facing error codes: `email_required`, `name_required`,
`content_required`, `message_too_long`, `rate_limited`.

## Payments

`usePayment(target)` pays an order (from `useCheckout`) or a booking's
deposit. The order's buyer token comes from the runtime's own order key;
the booking's manage token from `rememberBookingToken(id, token)` in
`src/booking-token.ts`, which the booking hook (step 5) calls. The payment
token comes back in `X-Payment-Token` and is never returned to the page.

The payment routes (`src/payment-api.ts`):

| Request | Answer |
| --- | --- |
| `POST /site/v1/store/orders/{id}/pay` (`X-Order-Token`) | `{ intent }` and `X-Payment-Token` |
| `POST /site/v1/bookings/bookings/{id}/payment` (`X-Booking-Token`) | `{ intent }` and `X-Payment-Token` |
| `GET /site/v1/payments/{intentId}` (`X-Payment-Token`) | `{ payment }`: state, amount, reference, methods, claim |
| `POST /site/v1/payments/{intentId}/stk` | `{ phone }`, answers `201` with `{ attempt }` |
| `POST /site/v1/payments/{intentId}/paystack` | `{ return_path }`, answers `{ attempt, next_url }` |
| `POST /site/v1/payments/{intentId}/paystack/verify` | `{ state }` |
| `POST /site/v1/payments/{intentId}/claims` | `{ sms }` or `{ code, amount }`, answers `201` with `{ claim }` |

A Paystack checkout is opened only when its URL is https on
`checkout.paystack.com`. The hook polls while a payment can still change, with
a growing wait, and stops when it is final, when the page is hidden, and after
thirty minutes.

A failed automatic attempt says why: `lastAttempt` is the newest attempt, and
`failureMessage` is the visitor's words for its failure (`messages.ts`, the
`stk_` and `attempt_` keys). `intent.amountPaid` is what has counted toward the
intent.

## Bookings

`useBooking(slug)` runs a visitor's booking of one service: the service and its
form, the availability by model, a hold on the chosen time, and the booking.
`useManageBooking(id)` views, cancels and moves a booking, and `useShopperBookings()`
lists a signed-in shopper's bookings. The booking routes (`src/bookings.ts`,
`src/booking-api.ts`):

| Request | Answer |
| --- | --- |
| `GET /site/v1/bookings/services/{slug}` | `{ service }`: model, currency, add-ons, form, visitor policy, `resource_groups` when the policy lets a visitor choose |
| `GET /site/v1/bookings/services/{slug}/availability?from&to&party&addons&resource` | `{ model, from, to, time_zone, days \| dates \| sessions }` |
| `POST /site/v1/bookings/holds` (gateway sets `X-Visitor-Key`) | `201 { hold, token }` |
| `DELETE /site/v1/bookings/holds/{id}` (`X-Hold-Token`) | `204` |
| `POST /site/v1/bookings/holds/{id}/book` (`X-Hold-Token`, `Idempotency-Key`) | `201 { booking, token, payment? }` |
| `GET /site/v1/bookings/bookings` (a shopper's sign-in) | `{ bookings, total }` |
| `GET /site/v1/bookings/bookings/{id}` (`X-Booking-Token`, or a shopper's sign-in) | `{ booking }` |
| `GET /site/v1/bookings/bookings/{id}/cancellation` | `{ fee, refund_due, free_until, reschedule_until, time_zone }` |
| `POST /site/v1/bookings/bookings/{id}/cancel` | `{ booking, fee, refund_due, free_until, time_zone }` |
| `POST /site/v1/bookings/bookings/{id}/reschedule` | `{ booking }` |

The hold and manage tokens are read from the answers once, kept in the runtime,
and never returned to the page. A booking's manage token is kept in the owned key
`andishi:booking` (`src/booking-token.ts`), per booking id; each answer's token
replaces the one before it. A book's `Idempotency-Key` is made per attempt
(`newIdempotencyKey`, `src/booking-api.ts`) and reused on a retry after a network
failure or a 5xx. Each request's body is checked against the service's model,
rules, resources and form before it is sent, and the server decides every one.

## What the Worker does

For a request under `/_api/`, proxy it to the gateway's `/site/v1/` with
the rest of the path and the query unchanged. Forward the method, body,
`Origin`, `Cookie`, `Content-Type`, `Accept`, `X-Cart-Token`,
`X-Order-Token`, `User-Agent`, `Referer` and `Sec-CH-UA-Mobile` (analytics
reads them and keeps none), and the client address and country the gateway
trusts; set `X-Site-Key` to the site's key. A beacon to `/_api/collect` is
limited to 2 KiB, and on a preview host it is answered `202` without being
forwarded. Return the gateway's status, body and
`Set-Cookie` as they are, and never cache these responses.

For a request that matches a route in `routes.json`:

1. Serve `index.html` with status 200.
2. Inject the site settings before the app script:
   `<script>window.__ANDISHI__={"apiUrl":"…","siteKey":"pk_…"}</script>`.
3. Render `meta` into `<head>` (title, description, Open Graph, canonical,
   robots, JSON-LD).
4. Embed the page data:
   `<script id="andishi-data" type="application/json">{"path":"/about","meta":{…},"data":{…}}</script>`.
   Escape every `<` as the six characters `\u003c` so the JSON cannot
   close the script tag. `path` is the request path without a trailing
   slash (`/` for the home page).

For a path that matches no route, do the same with `notFound` data, status
404 and `noindex`.

Requests under `/_build/{buildId}/` map to
`sites/{host}/builds/{buildId}/` for any build of that site still kept.
They never change, so serve them with
`Cache-Control: public, max-age=31536000, immutable`. A request for a
build that is gone returns 404; the runtime then reloads the page once and
picks up the live build.

Previews are served on their own origin, `{buildId}.preview.<platform
domain>`, where every path resolves against that build instead of the
live pointer. Generated links are root-relative (`href="/menu"`), so a
path prefix would send visitors out of the preview; a separate origin
keeps every link, reload and new tab inside it.

## Local development

```sh
VITE_ANDISHI_API_URL=http://localhost:8080 VITE_ANDISHI_SITE_KEY=pk_dev npm run dev
```

To test shopper sign-in locally, proxy `/_api` to the gateway's
`/site/v1` in the Vite dev server and set `VITE_ANDISHI_API_URL=/_api`,
so the sign-in cookie is same-origin as it is behind the Worker.

Without the Worker there is no embedded data, so the first page also loads
through `GET /site/v1/page`.
